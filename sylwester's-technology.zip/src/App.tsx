import React from 'react';
import { motion } from 'motion/react';
import { Cpu, Globe, Code, Rocket, Users, Mail, ArrowRight, Github, ExternalLink, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-tech-dark/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <span className="text-xl font-display font-bold tracking-tighter text-tech-blue">
              SYLWESTER<span className="text-white">'S</span> TECH
            </span>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {['Courses', 'Projects', 'Faculty', 'Events'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-gray-400 hover:text-white transition-colors text-sm font-medium"
                >
                  {item}
                </a>
              ))}
              <button className="bg-tech-blue hover:bg-blue-600 text-white px-5 py-2 rounded-full text-sm font-semibold transition-all">
                Join Now
              </button>
            </div>
          </div>
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-400 hover:text-white">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-tech-dark border-b border-white/5 p-4 space-y-4">
          {['Courses', 'Projects', 'Faculty', 'Events'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="block text-gray-400 hover:text-white text-base font-medium"
              onClick={() => setIsOpen(false)}
            >
              {item}
            </a>
          ))}
          <button className="w-full bg-tech-blue text-white px-5 py-3 rounded-xl text-sm font-semibold">
            Join Now
          </button>
        </div>
      )}
    </nav>
  );
};

const Hero = () => (
  <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden tech-grid">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <span className="inline-block py-1 px-3 rounded-full bg-tech-blue/10 text-tech-blue text-xs font-bold tracking-widest uppercase mb-6 border border-tech-blue/20">
          Innovation & Excellence
        </span>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
          SHAPING THE <br />
          <span className="text-tech-blue">DIGITAL FUTURE</span>
        </h1>
        <p className="max-w-2xl mx-auto text-gray-400 text-lg md:text-xl mb-10 font-light">
          At Sylwester's Technology section, we empower the next generation of innovators through hands-on learning, cutting-edge research, and creative problem-solving.
        </p>

      </motion.div>
    </div>
    {/* Decorative elements */}
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-tech-blue/10 rounded-full blur-[120px] -z-10" />
  </section>
);

const Courses = () => {
  const courses = [
    {
      title: 'Robotics & Automation',
      desc: 'Build and program autonomous systems using Arduino, Raspberry Pi, and industrial-grade components.',
      icon: <Cpu className="text-tech-blue" size={32} />,
      tags: ['Hardware', 'C++', 'IoT']
    },
    {
      title: 'AI & Data Science',
      desc: 'Master machine learning algorithms, neural networks, and data visualization to solve real-world problems.',
      icon: <Rocket className="text-tech-blue" size={32} />,
      tags: ['Python', 'TensorFlow', 'Stats']
    },
    {
      title: 'Web Engineering',
      desc: 'Create modern, responsive web applications using the latest frameworks and cloud technologies.',
      icon: <Globe className="text-tech-blue" size={32} />,
      tags: ['React', 'Node.js', 'Cloud']
    },
    {
      title: 'Cyber Security',
      desc: 'Learn the fundamentals of network security, ethical hacking, and digital forensics.',
      icon: <Code className="text-tech-blue" size={32} />,
      tags: ['Security', 'Linux', 'Networking']
    }
  ];

  return (
    <section id="courses" className="py-24 bg-black/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Core Curriculum</h2>
          <p className="text-gray-400 max-w-xl">Specialized tracks designed to bridge the gap between academic theory and industry practice.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courses.map((course, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -5 }}
              className="glass-card p-8 flex flex-col h-full"
            >
              <div className="mb-6">{course.icon}</div>
              <h3 className="text-xl font-bold mb-3">{course.title}</h3>
              <p className="text-gray-400 text-sm mb-6 flex-grow leading-relaxed">
                {course.desc}
              </p>
              <div className="flex flex-wrap gap-2">
                {course.tags.map(tag => (
                  <span key={tag} className="text-[10px] font-mono uppercase tracking-wider bg-white/5 px-2 py-1 rounded border border-white/5 text-gray-300">
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Projects = () => {
  const projects = [
    {
      title: 'Smart Campus Grid',
      category: 'IoT / Energy',
      image: 'https://picsum.photos/seed/tech1/800/600',
      student: 'Alex Rivera'
    },
    {
      title: 'Eco-Drone System',
      category: 'Robotics',
      image: 'https://picsum.photos/seed/tech2/800/600',
      student: 'Sarah Chen'
    },
    {
      title: 'Neural Language Lab',
      category: 'AI / NLP',
      image: 'https://picsum.photos/seed/tech3/800/600',
      student: 'Marcus Thorne'
    }
  ];

  return (
    <section id="projects" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Student Innovation</h2>
            <p className="text-gray-400 max-w-xl">Showcasing the exceptional work of our students across various technology disciplines.</p>
          </div>
          <button className="text-tech-blue font-semibold flex items-center gap-2 hover:underline">
            View All Projects <ExternalLink size={16} />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {projects.map((project, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-4">
                <img
                  src={project.image}
                  alt={project.title}
                  className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <div className="flex items-center gap-2 text-white text-sm">
                    <Github size={18} /> Source Code
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-tech-blue text-xs font-mono uppercase tracking-widest mb-1 block">
                    {project.category}
                  </span>
                  <h3 className="text-xl font-bold group-hover:text-tech-blue transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-500 text-sm mt-1">Lead: {project.student}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Faculty = () => {
  const members = [
    { name: 'Dr. Elena Vance', role: 'Head of Robotics', image: 'https://picsum.photos/seed/person1/400/400' },
    { name: 'Prof. Julian Kross', role: 'AI Research Lead', image: 'https://picsum.photos/seed/person2/400/400' },
    { name: 'Dr. Sarah Miller', role: 'Cybersecurity Expert', image: 'https://picsum.photos/seed/person3/400/400' },
    { name: 'Eng. David Wu', role: 'Systems Architect', image: 'https://picsum.photos/seed/person4/400/400' }
  ];

  return (
    <section id="faculty" className="py-24 bg-black/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Expert Mentors</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Learn from industry veterans and distinguished researchers who are passionate about education.</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {members.map((member, idx) => (
            <div key={idx} className="text-center">
              <div className="relative w-32 h-32 md:w-40 md:h-40 mx-auto mb-6 rounded-full overflow-hidden border-2 border-white/5 p-1">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover rounded-full grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h3 className="font-bold text-lg">{member.name}</h3>
              <p className="text-tech-blue text-sm font-medium">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="bg-tech-dark border-t border-white/5 pt-20 pb-10">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
        <div className="col-span-1 md:col-span-2">
          <span className="text-2xl font-display font-bold tracking-tighter text-tech-blue mb-6 block">
            SYLWESTER<span className="text-white">'S</span> TECHNOLOGY
          </span>
          <p className="text-gray-400 max-w-sm mb-8 leading-relaxed">
            Building the foundation for tomorrow's technology leaders. Join our community of innovators and creators.
          </p>
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-tech-blue transition-colors cursor-pointer">
              <Github size={20} />
            </div>
            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-tech-blue transition-colors cursor-pointer">
              <Mail size={20} />
            </div>
            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-tech-blue transition-colors cursor-pointer">
              <Users size={20} />
            </div>
          </div>
        </div>
        <div>
          <h4 className="font-bold mb-6 uppercase text-xs tracking-widest text-gray-500">Quick Links</h4>
          <ul className="space-y-4 text-gray-400 text-sm">
            <li><a href="#courses" className="hover:text-white transition-colors">Curriculum</a></li>
            <li><a href="#projects" className="hover:text-white transition-colors">Student Work</a></li>
            <li><a href="#faculty" className="hover:text-white transition-colors">Our Team</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Admissions</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-6 uppercase text-xs tracking-widest text-gray-500">Contact</h4>
          <ul className="space-y-4 text-gray-400 text-sm">
            <li className="flex items-center gap-2"><Mail size={16} /> tech@sylwesters.edu</li>
            <li className="flex items-center gap-2"><Globe size={16} /> Main Campus, Block T</li>
          </ul>
        </div>
      </div>
      <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-500 text-xs">
        <p>© 2024 Sylwester's Technology Section. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-white">Privacy Policy</a>
          <a href="#" className="hover:text-white">Terms of Service</a>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Courses />
        <Projects />
        <Faculty />
        <section className="py-24 bg-tech-blue">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-5xl font-bold mb-8 text-white tracking-tight">
              READY TO BUILD THE FUTURE?
            </h2>
            <p className="text-white/80 max-w-xl mx-auto mb-10 text-lg">
              Applications for the 2024-2025 academic year are now open. Secure your spot in our innovation lab today.
            </p>
            <button className="bg-white text-tech-blue hover:bg-gray-100 px-10 py-4 rounded-full text-lg font-bold transition-all shadow-xl">
              Apply Now
            </button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
